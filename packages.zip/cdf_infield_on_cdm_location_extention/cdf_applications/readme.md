Validate:
dataStorage.appInstanceSpace must be set for users to be able to upload or change any data in infield
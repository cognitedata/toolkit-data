# COMMON modules

The common directory contains modules that define resources that have an impact across an entire CDF project.
Typically these are related to authentication and authorization, as well as other global configurations like
global data models etc.

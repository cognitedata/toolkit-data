# cdf_infield_quickstart_common

This module contains shared configurations across multiple locations for Infield.
